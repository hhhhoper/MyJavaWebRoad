package 类和对象的练习.编程题.test01;

public class Test {
    public static void main(String[] args) {
        Point p1=new Point(0, 0);
        p1.movePoint(1,1);
        p1.printPoint();
        Point p2=new Point(0,0);
        p2.movePoint(2, 2);
        p2.printPoint();
    }
}
