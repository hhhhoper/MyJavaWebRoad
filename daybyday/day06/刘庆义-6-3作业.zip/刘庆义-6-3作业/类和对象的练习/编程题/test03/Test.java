package 类和对象的练习.编程题.test03;

public class Test {
    public static void main(String[] args) {
        Noterbook noterbook=new Noterbook('蓝', 12);              
        noterbook.printInfo();
    }
}
