package 类和对象的练习.编程题.test05;

public class VehicleTest {
     public static void main(String[] args) {
         Vehicle car=new Vehicle("black", "benz");    
         car.run();      
     }              
}
