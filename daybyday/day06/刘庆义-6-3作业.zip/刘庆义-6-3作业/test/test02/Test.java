package test.test02;

public class Test {
    public static void main(String[] args) {
      Circle cir=new Circle(8);
      cir.showArea();
      cir.showPerimeter();
    }
}
