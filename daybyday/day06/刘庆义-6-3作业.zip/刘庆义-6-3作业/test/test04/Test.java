package test.test04;

public class Test {
  public static void main(String[] args) {
   Card card=new Card("黑桃","A");
   card.showCard();
  }
}
