package test.test08;

public class Test {
    public static void main(String[] args) {
         Book book=new Book("JavaWeb实战","No0003", "387648797524", 58.8, "2017-01-01");
         book.showBook();
    }           
}
