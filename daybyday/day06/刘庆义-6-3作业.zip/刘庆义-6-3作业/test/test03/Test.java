package test.test03;

public class Test {
   public static void main(String[] args) {
    MyDate date =new MyDate(1900, 1, 1);
    date.showDate();  
    date.isBi(1900);
    
   }        
}
