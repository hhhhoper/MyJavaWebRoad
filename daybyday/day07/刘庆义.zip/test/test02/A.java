package test.test02;

public abstract class A {
    int numa=10;
    abstract void showA();
       
}
