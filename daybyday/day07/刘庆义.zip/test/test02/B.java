package test.test02;

public abstract class B extends A{
    int numb=20;
    abstract void showB();   
}
