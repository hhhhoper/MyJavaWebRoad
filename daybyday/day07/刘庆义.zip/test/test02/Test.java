package test.test02;

public class Test {
    public static void main(String[] args) {
        C c=new C();
        c.showA();
        c.showB();
        c.showC();
    }
}
