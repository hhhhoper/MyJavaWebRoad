package test.test05;

public class Example {
   public static void main(String[] args) {
      Circle circle=new Circle(10);
      Rectangle rectangle=new Rectangle(10, 5);
      rectangle.perimeter();
      rectangle.area();
      circle.perimeter();
      circle.area();
   
   }
}
