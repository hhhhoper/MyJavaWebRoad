package test.test06;

public abstract class Employee {
    String name;
    String id;
    String department;
    public abstract void print();
}
