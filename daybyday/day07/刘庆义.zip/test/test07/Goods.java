package test.test07;

public class Goods {
     String name;
     String id;
     double price;
     public Goods(String name,String id,double price){
         this.name=name;
         this.id=id;
         this.price=price;
     }
}
