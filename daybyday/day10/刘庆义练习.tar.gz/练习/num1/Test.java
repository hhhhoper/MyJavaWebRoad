package 练习.num1;

public class Test {
                   public static void main(String[] args) {
                                      Dog dog1=new Dog("哮天犬","猎狗","二郎神","10000","19");
                                      System.out.println(dog1.toString());
                                      Dog dog2=new Dog("罗小黑","神奇犬","大自然","999.99","1");
                                      
                                      System.out.println(dog2.toString());
                   }
}
