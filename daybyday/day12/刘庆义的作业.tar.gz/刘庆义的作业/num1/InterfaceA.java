package day12.作业.num1;
interface InterfaceA{
    public int method(int n);
} 