package day12.作业.num3;

public class Waiter extends Worker{
         public Waiter(double bsSalary){
                   this.bsSalary=bsSalary;
                   super.printSalary();
         }
}
