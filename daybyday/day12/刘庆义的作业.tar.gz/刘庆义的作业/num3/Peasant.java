package day12.作业.num3;

public class Peasant extends Worker{
                   public Peasant(double bsSalary){
                                      this.bsSalary=bsSalary;
                                      printSalary();
                            } 
}
