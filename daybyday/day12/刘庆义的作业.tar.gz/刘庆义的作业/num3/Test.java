package day12.作业.num3;

public class Test {
                   public static void main(String[] args) {
                          Worker worker=new Worker(10001);
                          Waiter waiter=new Waiter(10002);
                          Teacher teacher=new Teacher(10003, 1); 
                          Scientist scientist=new Scientist(10004, 1); 
                          Peasant peasant=new Peasant(10005);          
                   }
}
