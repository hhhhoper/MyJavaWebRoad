package day12.作业.num2;

public class Test {
     public static void main(String[] args) {
                   Teacher teacher=new Lecturer("小明",30,"讲师") ;      
                   teacher.introduce(); 
     }     
}
