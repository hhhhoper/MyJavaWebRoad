package day12.作业.num2;

public class Teacher {
     String name;
     int age;
     String post;
     double salary;
     public void introduce(){
                   System.out.println("姓名:"+name+"\n年龄:"+age+"\n工资:"+salary+"\n职称:"+post);
     }
}
