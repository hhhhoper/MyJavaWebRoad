package nu1;
interface Shape{
    abstract double calculateArea();
}