package nu4;

public class Test {
     public static void main(String[] args) {
         ConsoleLogger logger=new ConsoleLogger();
         logger.log("hello");
     }
}
