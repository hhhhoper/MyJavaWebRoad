package nu4;

public interface Logger {
       abstract void log(String message);
}
