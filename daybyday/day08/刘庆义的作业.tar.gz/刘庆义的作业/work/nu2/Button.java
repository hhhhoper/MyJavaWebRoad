package nu2;

public class Button implements Resizable {
   
     public void resize(int weight,int height){
         System.out.println("按钮高度:"+height+"\n按钮宽度:"+weight);
     }

}
