package nu2;

public class Test {
            public static void main(String[] args) {
                   Button button=new Button();
                   button.resize(10, 10);
            }

}
