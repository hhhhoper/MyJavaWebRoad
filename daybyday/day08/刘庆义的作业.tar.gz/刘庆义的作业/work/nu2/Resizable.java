package nu2;

public interface Resizable {
    abstract void resize(int width,int height);
}
