package nu3;

public interface Animal {
    abstract void sound();
}
