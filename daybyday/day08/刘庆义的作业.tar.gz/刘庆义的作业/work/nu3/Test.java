package nu3;

public class Test {
      public static void main(String[] args) {
                Dog dog=new Dog();
                dog.sound();
                Cat cat=new Cat();
                cat.sound();   
      }
}
