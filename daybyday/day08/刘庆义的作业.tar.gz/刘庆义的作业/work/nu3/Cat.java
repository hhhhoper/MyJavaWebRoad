package nu3;

public class Cat implements Animal{
      public void sound(){
                   System.out.println("喵喵叫");
      }
}
